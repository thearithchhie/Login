import React from 'react';
import './App.css';
import 'antd/dist/antd.css';
//import Login from './components/Login';
import Classlogin from './components/Classlogin';
const  App = () => {
  return(
   <div className="App">
      {/* <Login /> */}
      <Classlogin />
   </div>
  )
}

export default App;
